mymixedtypelist = [45,21,"vathsala","45"]
for item in mymixedtypelist :
    print("{} is of the data type {}".format(item,type(item)))