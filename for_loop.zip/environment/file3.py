name1= "vathsala"
name2= " S..<3"
name3= name1+name2
print(name3)