myFruitlist=("apple", "banana", "orange" )
print(myFruitlist)
print(type(myFruitlist))