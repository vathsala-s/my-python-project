dicto={
    "vathsala" : "student name",
    "123456" : "usn",
    "8th sem" : "semester"
    
}
print(dicto) #prints the dict
print(type(dicto)) #class define
print(dicto["vathsala"])
print(dicto["8th sem"])